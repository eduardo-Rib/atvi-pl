export default class Servico {
    constructor(
        public nome: string,
        public descricao: string,
        public preco: number
    ) {}
}