export default class Produto {
    constructor(
        public nome: string,
        public descricao: string,
        public preco: number
    ) {}
}