import Entrada from "../io/entrada";
import Empresa from "../modelo/empresa";
import CadastroCliente from "../negocio/cadastroCliente";
import ListagemClientes from "../negocio/listagemClientes";
import CadastroProduto from "../negocio/cadastroProduto";
import CadastroServico from "../negocio/cadastroServico";
import RegistroConsumo from "../negocio/registroConsumo";
import Top10ClientesQuantidade from "../negocio/top10ClientesQuantidade";
import Top5ClientesValor from "../negocio/top5ClientesValor";
import ListagemMaisConsumidos from "../negocio/listagemMaisConsumidos";

console.log(`Bem-vindo ao melhor sistema de gerenciamento de pet shops e clínicas veterinárias`);
let empresa = new Empresa();
let execucao = true;

while (execucao) {
    console.log(`\nOpções:`);
    console.log(`1 - Cadastrar cliente`);
    console.log(`2 - Listar todos os clientes`);
    console.log(`3 - Cadastrar produto`);
    console.log(`4 - Cadastrar serviço`);
    console.log(`5 - Registrar consumo de cliente`);
    console.log(`6 - Listar top 10 clientes por quantidade de consumo`);
    console.log(`7 - Listar top 5 clientes por valor de consumo`);
    console.log(`8 - Listar produtos e serviços mais consumidos`);
    console.log(`0 - Sair`);

    let entrada = new Entrada();
    let opcao = entrada.receberNumero(`\nPor favor, escolha uma opção: `);

    switch (opcao) {
        case 1:
            new CadastroCliente(empresa.getClientes).cadastrar();
            break;
        case 2:
            new ListagemClientes(empresa.getClientes).listar();
            break;
        case 3:
            new CadastroProduto(empresa.getProdutos).cadastrar();
            break;
        case 4:
            new CadastroServico(empresa.getServicos).cadastrar();
            break;
        case 5:
            new RegistroConsumo(empresa.getClientes, empresa.getProdutos, empresa.getServicos).registrar();
            break;
        case 6:
            new Top10ClientesQuantidade(empresa.getClientes).listar();
            break;
        case 7:
            new Top5ClientesValor(empresa.getClientes).listar();
            break;
        case 8:
            new ListagemMaisConsumidos(empresa.getClientes).listar();
            break;
        case 0:
            execucao = false;
            console.log(`Até mais!`);
            break;
        default:
            console.log(`Operação não entendida :(`);
    }
}
