
# Atividade 1 - Projeto PetLovers (PL) – Sistema CLI

Este repositório apresenta o sistema **PetLovers (PL)** em sua versão CLI (Interface de Linha de Comando), desenvolvido com **TypeScript** como parte da atividade prática orientada pelo Professor Dr. Eng. Gerson Penha.

---

## 🎯 Objetivo

Criar um sistema de linha de comando (CLI) para gerenciamento completo de pet shops e clínicas veterinárias, com foco em operações de cadastro, registro de consumo e geração de estatísticas.

---

## 🧰 Tecnologias Utilizadas

- **TypeScript** – linguagem principal do projeto
- **Node.js** – ambiente de execução
- **VSCode** – editor recomendado para desenvolvimento

---

## 🛠️ Funcionalidades

O sistema é executado via terminal e permite:

### 👥 Clientes
- CRUD (Create, Read, Update, Delete) de clientes
- Registro de informações: nome, nome social, CPF, RG e telefones

### 🐾 Pets
- Associação de múltiplos pets a cada cliente
- Informações registradas: nome, tipo, raça e gênero

### 🛍️ Produtos e Serviços
- Cadastro, edição, visualização e remoção de produtos e serviços

### 🧾 Registro de Consumo
- Registro de consumo de produtos e serviços por cliente

### 📊 Estatísticas
- Top 10 clientes que mais consumiram (quantidade)
- Top 5 clientes que mais consumiram (valor)
- Produtos e serviços mais consumidos no geral
- Produtos e serviços mais consumidos por **tipo e raça de pet**

---

## 🎥 Demonstração em Vídeo

> *(Espaço reservado para link do vídeo demonstrativo)*

---

## 🚀 Como Executar o Projeto

> Pré-requisitos: Node.js e TypeScript instalados

```bash
# Instale as dependências
npm install

# Compile o TypeScript
npx tsc

# Execute o sistema
node dist/app.js
```

---

## 🧠 Contexto

O projeto nasce como resposta ao crescimento acelerado do mercado pet no Brasil, com faturamento de R$ 58,9 bilhões em 2022. O sistema PetLovers visa atender lojas de comércio eletrônico, pet shops e clínicas veterinárias, oferecendo uma solução moderna, mesmo em ambientes sem interface gráfica.

---

## 👨‍💻 Desenvolvedor

Este sistema foi desenvolvido como parte da atividade prática da disciplina de Engenharia de Software, com foco em estruturação de classes, modelagem de dados e interação por linha de comando.

---

## 📄 Licença

Projeto educacional sem fins lucrativos – Licença MIT.
